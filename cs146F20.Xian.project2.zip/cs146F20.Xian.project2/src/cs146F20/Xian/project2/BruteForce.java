package cs146F20.Xian.project2;

/*
 * This class is the brute force method for finding the maximum subarray
 */

public class BruteForce {
	
	/*
	 * Find the maximum subarray of the input array, as well as the best arriving and departing day
	 * 
	 * @param int[] arr: the input array which we are going to traverse 
	 * @param int begin: the index we begin at
	 * @param int end: the index we end at
	 * 
	 * @return: an array containing the maximum sum, the arriving day, the departing day
	 */
	int[] bruteForceFindMaxSubArray(int[] arr)
	{
		//Initialize the maximum sum as the first element of the array
		int maxSum = arr[0];
		//The sum of the current subarray
		int currentSum = 0;
		//Record the best arriving and departing day
		int arrive = -1;
		int depart = -1;
		
		for(int i = 0; i < arr.length; i++)
		{
			//Initilize sum to 0
			currentSum = 0;
			for(int j = i; j < arr.length; j++)
			{
				currentSum += arr[j];
				
				//Replace maxSum if find a larger sum
				//Record corresponding i and j for the new maxSum as well
				if(currentSum > maxSum)
				{
					maxSum = currentSum;
					arrive = i;
					depart = j;
				}
			}
		}
		
		//Store the maximum sum, arriving day, departing day in an array
		int[] answer = new int[3];
		answer[0] = maxSum;
		answer[1] = arrive;
		answer[2] = depart;
		return answer;
	}

}
