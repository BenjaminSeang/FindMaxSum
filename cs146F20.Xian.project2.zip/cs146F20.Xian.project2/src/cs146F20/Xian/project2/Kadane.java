package cs146F20.Xian.project2;

public class Kadane {
	
	
	/*
	 * Find the maximum subarray of the input array, as well as the best arriving and departing day
	 * 
	 * @param int[] arr: the input array which we are going to traverse 
	 * 
	 * @return: an array containing the maximum sum, the arriving day, the departing day
	 */
	int[] kadaneFindMaxArray(int[] arr)
	{
		//Initialization
		int maxSum = 0;
		int maxTemp = 0;
		int arrive = 0;
		int depart = 0;
		int tempArrive = 0;
		
		//Kadane Algorithm
		for(int i = 0; i < arr.length; i++)
		{
			maxTemp = maxTemp + arr[i];
			if(maxTemp < 0)
			{
				maxTemp = 0;
				arrive = i + 1;
			}
			if(maxSum < maxTemp)
			{
				maxSum = maxTemp;
				depart = i;
				tempArrive = arrive;
			}
		}
		arrive = tempArrive;
		
		//return the answer set
		int[] answer = new int[3];
		answer[0] = maxSum;
		answer[1] = arrive;
		answer[2] = depart;
		return answer;
	}
	
}

