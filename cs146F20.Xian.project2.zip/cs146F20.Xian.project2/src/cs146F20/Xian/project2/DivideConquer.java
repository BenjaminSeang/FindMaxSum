package cs146F20.Xian.project2;

/*
 * This class is the divide-and-conquer method for finding the maximum subarray
 */
public class DivideConquer {
	

	/*
	 * Find the maximum subarray of the input array, as well as the best arriving and departing day
	 * 
	 * @param int[] arr: the input array which we are going to traverse 
	 * @param int l: the leftmost index
	 * @param int h: the rightmost index
	 * 
	 * @return: an array containing the maximum sum, the arriving day, the departing day
	 */
	int[] findMaxSubarray(int[] arr, int l, int h)
	{
		//Base case, when there's only one element in the array
		if(l == h)
		{
			
			return (new int[] {arr[l], l, h});
		}
		else
		{
			//Find the middle point
			int m = (l + h)/2;
			
			int leftMax[] = findMaxSubarray(arr, l, m);
			int rightMax[] = findMaxSubarray(arr, m+1, h);
			int crossMax[] = findMaxCrossingSubarray(arr, l, m, h);
			int answer = Math.max(crossMax[0], Math.max(leftMax[0], rightMax[0]));
			
			if(answer == crossMax[0])
			{
				return crossMax;
			}
			else if(answer == leftMax[0])
			{
				return leftMax;
			}
			else
			{
				return rightMax;
			}
			
		}

	}
	
	/*
	 * Find the maximum subarray of a array which crosses the middle of the original array
	 * 
	 * @param int[] arr: the input array which we are going to traverse 
	 * @param int l: the leftmost index
	 * @param int m: the middle index
	 * @param int h: the rightmost index
	 * 
	 * @return: an array containing the maximum sum, the arriving day, the departing day
	 */
	
	int[] findMaxCrossingSubarray(int[] arr, int l, int m, int h)
	{
		int arrive = -1;
		int depart = -1;
		//Find the maximum sum of the left array
		int sum = 0; 
		int leftSum = Integer.MIN_VALUE;
		for (int i = m; i >= l; i--) 
		{ 
			sum = sum + arr[i]; 
			if (sum > leftSum)
			{
				leftSum = sum; 
				arrive = i;
			}

		} 

		//Find the maximum sum of the right array
		sum = 0; 
		int rightSum = Integer.MIN_VALUE; 
		for (int i = m + 1; i <= h; i++) 
		{ 
			sum = sum + arr[i]; 
			if (sum > rightSum)
			{
				rightSum = sum;
				depart = i;
			}
		}

		int crossSum = rightSum + leftSum;
		int largest =  Math.max(crossSum, Math.max(leftSum, rightSum));
		
		return new int[]{largest, arrive, depart};

	}

}
