package cs146F20.Xian.project2;
import java.io.*;

/*
 * This class is used to read from maxSumtest.txt
 * and format the input
 * 
 */

public class MyReader {
	
	BufferedReader br;
	
	//Constructor
	public MyReader(BufferedReader in)
	{
		br = new BufferedReader(in);
	}
	
	/*
	 * Read in a data string
	 * Split it by white spaces
	 * Convert it into a int array 
	 */
	public int[] readTestingArr() throws IOException, NumberFormatException
	{
		String[] input = new String[103];
		int[] output = new int[103];
		String line;
		
		//Skip empty lines
		line = br.readLine();
		while(line.length() == 0)
		{
			line = br.readLine();
		}
		
		//Split the line read by "  " two white spaces
		//Put each splited element into String[] input 
		input = line.split("  ");
		
		//Remove all reamining white spaces if any (to avoid casting error later)
		for(int i = 0; i < input.length; i++)
		{
			input[i] = input[i].replaceAll(" ", "");
		}
		
		//Convert each String element of input into int
		//Store the converted element in output
		for(int i = 0; i < output.length; i++)
		{
			output[i] = Integer.parseInt(input[i]);
		}
		
		//Return a formatted int array that is ready to be tested on
		return output;
		
	}

}
