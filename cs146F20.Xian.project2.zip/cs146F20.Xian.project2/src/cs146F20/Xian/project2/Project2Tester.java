package cs146F20.Xian.project2;

import static org.junit.jupiter.api.Assertions.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import org.junit.Before;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;

class Project2Tester{
	//An array which holds the whole line of data read from maxSumtest.txt
	int[] inputArr;
	//An array which holds the first 100 elemnts of the line, which will be used for testing the three algorithms
	int[] testingArr;
	//An array which holds the last 3 elments (correct max sum, correct arrive date, correct depart date) of the line
	//Will be compared to my answers
	int[] answerArr;
	
	//Declare the instances to be tested
	BruteForce bf = new BruteForce();
	Kadane kd = new Kadane();
	DivideConquer dc = new DivideConquer();
	
	@Before
	void setUp()
	{
		//Initilize data for each test
		inputArr = new int[103];
		testingArr = new int[100];
		answerArr = new int[3];
	}

	
	//////////////////////////////////////////////////////////////////////////
	//                                                                      //
	//                                                                      //
	//     The following 10 tests are using the Professor's data            //
	//                                                                      //
	//                                                                      //
	//////////////////////////////////////////////////////////////////////////
	
	@Test
	void test1() throws NumberFormatException, IOException{
		
		setUp();

		File input = new File("maxSumtest.txt");
		MyReader mr = new MyReader(new BufferedReader(new FileReader(input)));

		//Get total 103 elemnts
		inputArr = mr.readTestingArr();
		//Assign the first 100 elemnts to the testing set
		for(int i = 0; i < testingArr.length; i++)
		{
			testingArr[i] = inputArr[i];
		}
		//Assign the last 3 elments to the answer set
		answerArr[0] = inputArr[inputArr.length - 3];
		answerArr[1] = inputArr[inputArr.length - 2];
		answerArr[2] = inputArr[inputArr.length - 1];



		//Brute Force Test Begin
		int[] bruteForceAnswer = new int[3];
		bruteForceAnswer = bf.bruteForceFindMaxSubArray(testingArr);
		assertTrue(bruteForceAnswer[0] == answerArr[0] && bruteForceAnswer[1] == answerArr[1] && bruteForceAnswer[2] == answerArr[2]);


		//Kadane Algorithm Test Begin
		int[] kadaneAnswer = new int[3];
		kadaneAnswer = kd.kadaneFindMaxArray(testingArr);
		assertTrue(kadaneAnswer[0] == answerArr[0] && kadaneAnswer[1] == answerArr[1] && kadaneAnswer[2] == answerArr[2]);
		
		
		//Divide Conquer Test Begin
		int[] divideConquerAnswer = new int[3];
		divideConquerAnswer = dc.findMaxSubarray(testingArr, 0, testingArr.length - 1);
		assertTrue(divideConquerAnswer[0] == answerArr[0]);
		
		
	}
	
	@Test
	void test2() throws NumberFormatException, IOException{
		
		setUp();
		
		File input = new File("maxSumtest.txt");
		MyReader mr = new MyReader(new BufferedReader(new FileReader(input)));
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		
		//Assign the first 100 elemnts to the testing set
		for(int i = 0; i < testingArr.length; i++)
		{
			testingArr[i] = inputArr[i];
		}
		
		//Assign the last 3 elments to the answer set
		answerArr[0] = inputArr[inputArr.length - 3];
		answerArr[1] = inputArr[inputArr.length - 2];
		answerArr[2] = inputArr[inputArr.length - 1];
		
		//Brute Force Test Begin
		int[] bruteForceAnswer = new int[3];
		bruteForceAnswer = bf.bruteForceFindMaxSubArray(testingArr);
		assertTrue(bruteForceAnswer[0] == answerArr[0] && bruteForceAnswer[1] == answerArr[1] && bruteForceAnswer[2] == answerArr[2]);


		//Kadane Algorithm Test Begin
		int[] kadaneAnswer = new int[3];
		kadaneAnswer = kd.kadaneFindMaxArray(testingArr);
		assertTrue(kadaneAnswer[0] == answerArr[0] && kadaneAnswer[1] == answerArr[1] && kadaneAnswer[2] == answerArr[2]);

		
		//Divide Conquer Test Begin
		int[] divideConquerAnswer = new int[3];
		divideConquerAnswer = dc.findMaxSubarray(testingArr, 0, testingArr.length - 1);
		assertTrue(divideConquerAnswer[0] == answerArr[0]);
		
	}
	
	@Test
	void test3() throws NumberFormatException, IOException{
		
		setUp();
		
		File input = new File("maxSumtest.txt");
		MyReader mr = new MyReader(new BufferedReader(new FileReader(input)));
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		
		//Assign the first 100 elemnts to the testing set
		for(int i = 0; i < testingArr.length; i++)
		{
			testingArr[i] = inputArr[i];
		}
		
		//Assign the last 3 elments to the answer set
		answerArr[0] = inputArr[inputArr.length - 3];
		answerArr[1] = inputArr[inputArr.length - 2];
		answerArr[2] = inputArr[inputArr.length - 1];
		
		//Brute Force Test Begin
		int[] bruteForceAnswer = new int[3];
		bruteForceAnswer = bf.bruteForceFindMaxSubArray(testingArr);
		assertTrue(bruteForceAnswer[0] == answerArr[0] && bruteForceAnswer[1] == answerArr[1] && bruteForceAnswer[2] == answerArr[2]);


		//Kadane Algorithm Test Begin
		int[] kadaneAnswer = new int[3];
		kadaneAnswer = kd.kadaneFindMaxArray(testingArr);
		assertTrue(kadaneAnswer[0] == answerArr[0] && kadaneAnswer[1] == answerArr[1] && kadaneAnswer[2] == answerArr[2]);

		
		//Divide Conquer Test Begin
		int[] divideConquerAnswer = new int[3];
		divideConquerAnswer = dc.findMaxSubarray(testingArr, 0, testingArr.length - 1);
		assertTrue(divideConquerAnswer[0] == answerArr[0]);
	}
	
	@Test
	void test4() throws NumberFormatException, IOException{
		
		setUp();
		
		File input = new File("maxSumtest.txt");
		MyReader mr = new MyReader(new BufferedReader(new FileReader(input)));
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		
		//Assign the first 100 elemnts to the testing set
		for(int i = 0; i < testingArr.length; i++)
		{
			testingArr[i] = inputArr[i];
		}
		
		//Assign the last 3 elments to the answer set
		answerArr[0] = inputArr[inputArr.length - 3];
		answerArr[1] = inputArr[inputArr.length - 2];
		answerArr[2] = inputArr[inputArr.length - 1];
		
		//Brute Force Test Begin
		int[] bruteForceAnswer = new int[3];
		bruteForceAnswer = bf.bruteForceFindMaxSubArray(testingArr);
		assertTrue(bruteForceAnswer[0] == answerArr[0] && bruteForceAnswer[1] == answerArr[1] && bruteForceAnswer[2] == answerArr[2]);


		//Kadane Algorithm Test Begin
		int[] kadaneAnswer = new int[3];
		kadaneAnswer = kd.kadaneFindMaxArray(testingArr);
		assertTrue(kadaneAnswer[0] == answerArr[0] && kadaneAnswer[1] == answerArr[1] && kadaneAnswer[2] == answerArr[2]);

		
		//Divide Conquer Test Begin
		int[] divideConquerAnswer = new int[3];
		divideConquerAnswer = dc.findMaxSubarray(testingArr, 0, testingArr.length - 1);
		assertTrue(divideConquerAnswer[0] == answerArr[0]);
	}
	
	@Test
	void test5() throws NumberFormatException, IOException{
		
		setUp();
		
		File input = new File("maxSumtest.txt");
		MyReader mr = new MyReader(new BufferedReader(new FileReader(input)));
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		
		//Assign the first 100 elemnts to the testing set
		for(int i = 0; i < testingArr.length; i++)
		{
			testingArr[i] = inputArr[i];
		}
		
		//Assign the last 3 elments to the answer set
		answerArr[0] = inputArr[inputArr.length - 3];
		answerArr[1] = inputArr[inputArr.length - 2];
		answerArr[2] = inputArr[inputArr.length - 1];
		
		//Brute Force Test Begin
		int[] bruteForceAnswer = new int[3];
		bruteForceAnswer = bf.bruteForceFindMaxSubArray(testingArr);
		assertTrue(bruteForceAnswer[0] == answerArr[0] && bruteForceAnswer[1] == answerArr[1] && bruteForceAnswer[2] == answerArr[2]);


		//Kadane Algorithm Test Begin
		int[] kadaneAnswer = new int[3];
		kadaneAnswer = kd.kadaneFindMaxArray(testingArr);
		assertTrue(kadaneAnswer[0] == answerArr[0] && kadaneAnswer[1] == answerArr[1] && kadaneAnswer[2] == answerArr[2]);

		
		//Divide Conquer Test Begin
		int[] divideConquerAnswer = new int[3];
		divideConquerAnswer = dc.findMaxSubarray(testingArr, 0, testingArr.length - 1);
		assertTrue(divideConquerAnswer[0] == answerArr[0]);
		
	}
	
	@Test
	void test6() throws NumberFormatException, IOException{
		
		setUp();
		
		File input = new File("maxSumtest.txt");
		MyReader mr = new MyReader(new BufferedReader(new FileReader(input)));
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		
		//Assign the first 100 elemnts to the testing set
		for(int i = 0; i < testingArr.length; i++)
		{
			testingArr[i] = inputArr[i];
		}
		
		//Assign the last 3 elments to the answer set
		answerArr[0] = inputArr[inputArr.length - 3];
		answerArr[1] = inputArr[inputArr.length - 2];
		answerArr[2] = inputArr[inputArr.length - 1];
		
		//Brute Force Test Begin
		int[] bruteForceAnswer = new int[3];
		bruteForceAnswer = bf.bruteForceFindMaxSubArray(testingArr);
		assertTrue(bruteForceAnswer[0] == answerArr[0] && bruteForceAnswer[1] == answerArr[1] && bruteForceAnswer[2] == answerArr[2]);


		//Kadane Algorithm Test Begin
		int[] kadaneAnswer = new int[3];
		kadaneAnswer = kd.kadaneFindMaxArray(testingArr);
		assertTrue(kadaneAnswer[0] == answerArr[0] && kadaneAnswer[1] == answerArr[1] && kadaneAnswer[2] == answerArr[2]);

		
		//Divide Conquer Test Begin
		int[] divideConquerAnswer = new int[3];
		divideConquerAnswer = dc.findMaxSubarray(testingArr, 0, testingArr.length - 1);
		assertTrue(divideConquerAnswer[0] == answerArr[0]);
		
	}
	
	@Test
	void test7() throws NumberFormatException, IOException{
		
		setUp();
		
		File input = new File("maxSumtest.txt");
		MyReader mr = new MyReader(new BufferedReader(new FileReader(input)));
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		
		//Assign the first 100 elemnts to the testing set
		for(int i = 0; i < testingArr.length; i++)
		{
			testingArr[i] = inputArr[i];
		}
		
		//Assign the last 3 elments to the answer set
		answerArr[0] = inputArr[inputArr.length - 3];
		answerArr[1] = inputArr[inputArr.length - 2];
		answerArr[2] = inputArr[inputArr.length - 1];
		
		//Brute Force Test Begin
		int[] bruteForceAnswer = new int[3];
		bruteForceAnswer = bf.bruteForceFindMaxSubArray(testingArr);
		assertTrue(bruteForceAnswer[0] == answerArr[0] && bruteForceAnswer[1] == answerArr[1] && bruteForceAnswer[2] == answerArr[2]);


		//Kadane Algorithm Test Begin
		int[] kadaneAnswer = new int[3];
		kadaneAnswer = kd.kadaneFindMaxArray(testingArr);
		assertTrue(kadaneAnswer[0] == answerArr[0] && kadaneAnswer[1] == answerArr[1] && kadaneAnswer[2] == answerArr[2]);

		
		//Divide Conquer Test Begin
		int[] divideConquerAnswer = new int[3];
		divideConquerAnswer = dc.findMaxSubarray(testingArr, 0, testingArr.length - 1);
		assertTrue(divideConquerAnswer[0] == answerArr[0]);
		
	}
	
	@Test
	void test8() throws NumberFormatException, IOException{
		
		setUp();
		
		File input = new File("maxSumtest.txt");
		MyReader mr = new MyReader(new BufferedReader(new FileReader(input)));
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		
		//Assign the first 100 elemnts to the testing set
		for(int i = 0; i < testingArr.length; i++)
		{
			testingArr[i] = inputArr[i];
		}
		
		//Assign the last 3 elments to the answer set
		answerArr[0] = inputArr[inputArr.length - 3];
		answerArr[1] = inputArr[inputArr.length - 2];
		answerArr[2] = inputArr[inputArr.length - 1];
		
		//Brute Force Test Begin
		int[] bruteForceAnswer = new int[3];
		bruteForceAnswer = bf.bruteForceFindMaxSubArray(testingArr);
		assertTrue(bruteForceAnswer[0] == answerArr[0] && bruteForceAnswer[1] == answerArr[1] && bruteForceAnswer[2] == answerArr[2]);


		//Kadane Algorithm Test Begin
		int[] kadaneAnswer = new int[3];
		kadaneAnswer = kd.kadaneFindMaxArray(testingArr);
		assertTrue(kadaneAnswer[0] == answerArr[0] && kadaneAnswer[1] == answerArr[1] && kadaneAnswer[2] == answerArr[2]);

		
		//Divide Conquer Test Begin
		int[] divideConquerAnswer = new int[3];
		divideConquerAnswer = dc.findMaxSubarray(testingArr, 0, testingArr.length - 1);
		assertTrue(divideConquerAnswer[0] == answerArr[0]);
		
	}
	
	@Test
	void test9() throws NumberFormatException, IOException{
		
		setUp();
		
		File input = new File("maxSumtest.txt");
		MyReader mr = new MyReader(new BufferedReader(new FileReader(input)));
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		
		//Assign the first 100 elemnts to the testing set
		for(int i = 0; i < testingArr.length; i++)
		{
			testingArr[i] = inputArr[i];
		}
		
		//Assign the last 3 elments to the answer set
		answerArr[0] = inputArr[inputArr.length - 3];
		answerArr[1] = inputArr[inputArr.length - 2];
		answerArr[2] = inputArr[inputArr.length - 1];
		
		//Brute Force Test Begin
		int[] bruteForceAnswer = new int[3];
		bruteForceAnswer = bf.bruteForceFindMaxSubArray(testingArr);
		assertTrue(bruteForceAnswer[0] == answerArr[0] && bruteForceAnswer[1] == answerArr[1] && bruteForceAnswer[2] == answerArr[2]);


		//Kadane Algorithm Test Begin
		int[] kadaneAnswer = new int[3];
		kadaneAnswer = kd.kadaneFindMaxArray(testingArr);
		assertTrue(kadaneAnswer[0] == answerArr[0] && kadaneAnswer[1] == answerArr[1] && kadaneAnswer[2] == answerArr[2]);

		
		//Divide Conquer Test Begin
		int[] divideConquerAnswer = new int[3];
		divideConquerAnswer = dc.findMaxSubarray(testingArr, 0, testingArr.length - 1);
		assertTrue(divideConquerAnswer[0] == answerArr[0]);
		
	}
	
	@Test
	void test10() throws NumberFormatException, IOException{
		
		setUp();
		
		File input = new File("maxSumtest.txt");
		MyReader mr = new MyReader(new BufferedReader(new FileReader(input)));
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		inputArr = mr.readTestingArr();
		
		//Assign the first 100 elemnts to the testing set
		for(int i = 0; i < testingArr.length; i++)
		{
			testingArr[i] = inputArr[i];
		}
		
		//Assign the last 3 elments to the answer set
		answerArr[0] = inputArr[inputArr.length - 3];
		answerArr[1] = inputArr[inputArr.length - 2];
		answerArr[2] = inputArr[inputArr.length - 1];
		
		//Brute Force Test Begin
		int[] bruteForceAnswer = new int[3];
		bruteForceAnswer = bf.bruteForceFindMaxSubArray(testingArr);
		assertTrue(bruteForceAnswer[0] == answerArr[0] && bruteForceAnswer[1] == answerArr[1] && bruteForceAnswer[2] == answerArr[2]);


		//Kadane Algorithm Test Begin
		int[] kadaneAnswer = new int[3];
		kadaneAnswer = kd.kadaneFindMaxArray(testingArr);
		assertTrue(kadaneAnswer[0] == answerArr[0] && kadaneAnswer[1] == answerArr[1] && kadaneAnswer[2] == answerArr[2]);

		
		//Divide Conquer Test Begin
		int[] divideConquerAnswer = new int[3];
		divideConquerAnswer = dc.findMaxSubarray(testingArr, 0, testingArr.length - 1);
		assertTrue(divideConquerAnswer[0] == answerArr[0]);
		
	}
	

	//////////////////////////////////////////////////////////////////////////
	//                                                                      //
	//                                                                      //
	//     The following tests are using my own data                        //
	//                                                                      //
	//                                                                      //
	//////////////////////////////////////////////////////////////////////////
	
	/*
	 * 	long startTime = System.nanoTime();
		.....your program....
		long endTime   = System.nanoTime();
		long totalTime = endTime - startTime;
	 */
	long BFStartTime;
	long BFEndTime;
	long BFTotalTime;
	long BFAvgTime;
	
	long DCStartTime;
	long DCEndTime;
	long DCTotalTime;
	long DCAvgTime;
	
	long KDStartTime;
	long KDEndTime;
	long KDTotalTime;
	long KDAvgTime;
	
	int[] arr100 = new int[100];
	int[] arr200 = new int[200];
	int[] arr500 = new int[500];
	int[] arr1000 = new int[1000];
	int[] arr2000 = new int[2000];
	int[] arr5000 = new int[5000];
	int[] arr10000 = new int[10000];
	
	
	/*
	 * Following tests will test the running time of three algorithms
	 * on Random arrays of size 100, 200 ,500, 1000, 2000, 5000, 10000
	 */
	
	
	@Test
	@Order(1)
	void testSize100() 
	{
		
		BFTotalTime = 0;
		DCTotalTime = 0;
		KDTotalTime = 0;
		
		for(int i = 0; i < 10; i++)
		{
			Random random = new Random();
			int randomNumber;
			for(int j = 0; j < 100; j++)
			{
				randomNumber=(random.nextInt(200)-100);
				arr100[j] = randomNumber;
			}
		
			int[] bruteAnswer= new int[3];
			int[] DCAnswer = new int[3];
			int[] kadaneAnswer = new int[3];
			
			
			BFStartTime = System.nanoTime();
			bruteAnswer = bf.bruteForceFindMaxSubArray(arr100);
			BFEndTime = System.nanoTime();
			BFTotalTime =+ (BFEndTime - BFStartTime);
			
			DCStartTime = System.nanoTime();
			DCAnswer = dc.findMaxSubarray(arr100, 0, arr100.length - 1);
			DCEndTime = System.nanoTime();
			DCTotalTime =+ (DCEndTime - DCStartTime);
			
			KDStartTime = System.nanoTime();
			kadaneAnswer = kd.kadaneFindMaxArray(arr100);
			KDEndTime = System.nanoTime();
			KDTotalTime =+ (KDEndTime - KDStartTime);
		}
		
		BFAvgTime = BFTotalTime/10;
		DCAvgTime = DCTotalTime/10;
		KDAvgTime = KDTotalTime/10;
		
		System.out.println("Size 100");
		System.out.println("BruteForce Average: " + BFAvgTime + " nano second");
		System.out.println("Divide&Conquer Average: " + DCAvgTime + " nano second");
		System.out.println("Kadane Average: " + KDAvgTime + " nano second");
		System.out.println();
	}
	
	@Test
	@Order(2)
	void testSize200() 
	{
		BFTotalTime = 0;
		DCTotalTime = 0;
		KDTotalTime = 0;
		
		
		for(int i = 0; i < 10; i++)
		{
			Random random = new Random();
			int randomNumber;
			for(int j = 0; j < 200; j++)
			{
				randomNumber=(random.nextInt(200)-100);
				arr200[j] = randomNumber;
			}
		
			int[] bruteAnswer= new int[3];
			int[] DCAnswer = new int[3];
			int[] kadaneAnswer = new int[3];
			
			
			BFStartTime = System.nanoTime();
			bruteAnswer = bf.bruteForceFindMaxSubArray(arr200);
			BFEndTime = System.nanoTime();
			BFTotalTime =+ (BFEndTime - BFStartTime);
			
			DCStartTime = System.nanoTime();
			DCAnswer = dc.findMaxSubarray(arr200, 0, arr200.length - 1);
			DCEndTime = System.nanoTime();
			DCTotalTime =+ (DCEndTime - DCStartTime);
			
			KDStartTime = System.nanoTime();
			kadaneAnswer = kd.kadaneFindMaxArray(arr200);
			KDEndTime = System.nanoTime();
			KDTotalTime =+ (KDEndTime - KDStartTime);
		}
		
		BFAvgTime = BFTotalTime/10;
		DCAvgTime = DCTotalTime/10;
		KDAvgTime = KDTotalTime/10;
		
		System.out.println("Size 200");
		System.out.println("BruteForce Average: " + BFAvgTime + " nano second");
		System.out.println("Divide&Conquer Average: " + DCAvgTime + " nano second");
		System.out.println("Kadane Average: " + KDAvgTime + " nano second");
		System.out.println();
	}
	
	@Test
	@Order(3)
	void testSize500() 
	{
		
		BFTotalTime = 0;
		DCTotalTime = 0;
		KDTotalTime = 0;
		
		for(int i = 0; i < 10; i++)
		{
			Random random = new Random();
			int randomNumber;
			for(int j = 0; j < 500; j++)
			{
				randomNumber=(random.nextInt(200)-100);
				arr500[j] = randomNumber;
			}
		
			int[] bruteAnswer= new int[3];
			int[] DCAnswer = new int[3];
			int[] kadaneAnswer = new int[3];
			
			
			
			BFStartTime = System.nanoTime();
			bruteAnswer = bf.bruteForceFindMaxSubArray(arr500);
			BFEndTime = System.nanoTime();
			BFTotalTime =+ (BFEndTime - BFStartTime);
			
			DCStartTime = System.nanoTime();
			DCAnswer = dc.findMaxSubarray(arr500, 0, arr500.length - 1);
			DCEndTime = System.nanoTime();
			DCTotalTime =+ (DCEndTime - DCStartTime);
			
			KDStartTime = System.nanoTime();
			kadaneAnswer = kd.kadaneFindMaxArray(arr500);
			KDEndTime = System.nanoTime();
			KDTotalTime =+ (KDEndTime - KDStartTime);
		}
		
		BFAvgTime = BFTotalTime/10;
		DCAvgTime = DCTotalTime/10;
		KDAvgTime = KDTotalTime/10;
		
		System.out.println("Size 500");
		System.out.println("BruteForce Average: " + BFAvgTime + " nano second");
		System.out.println("Divide&Conquer Average: " + DCAvgTime + " nano second");
		System.out.println("Kadane Average: " + KDAvgTime + " nano second");
		System.out.println();
	}
	
	@Test
	@Order(4)
	void testSize1000() 
	{
		BFTotalTime = 0;
		DCTotalTime = 0;
		KDTotalTime = 0;
		
		for(int i = 0; i < 10; i++)
		{
			Random random = new Random();
			int randomNumber;
			for(int j = 0; j < 1000; j++)
			{
				randomNumber=(random.nextInt(200)-100);
				arr1000[j] = randomNumber;
			}
		
			int[] bruteAnswer= new int[3];
			int[] DCAnswer = new int[3];
			int[] kadaneAnswer = new int[3];
			
			
			
			BFStartTime = System.nanoTime();
			bruteAnswer = bf.bruteForceFindMaxSubArray(arr1000);
			BFEndTime = System.nanoTime();
			BFTotalTime =+ (BFEndTime - BFStartTime);
			
			DCStartTime = System.nanoTime();
			DCAnswer = dc.findMaxSubarray(arr1000, 0, arr1000.length - 1);
			DCEndTime = System.nanoTime();
			DCTotalTime =+ (DCEndTime - DCStartTime);
			
			KDStartTime = System.nanoTime();
			kadaneAnswer = kd.kadaneFindMaxArray(arr1000);
			KDEndTime = System.nanoTime();
			KDTotalTime =+ (KDEndTime - KDStartTime);
		}
		
		BFAvgTime = BFTotalTime/10;
		DCAvgTime = DCTotalTime/10;
		KDAvgTime = KDTotalTime/10;
		
		System.out.println("Size 1000");
		System.out.println("BruteForce Average: " + BFAvgTime + " nano second");
		System.out.println("Divide&Conquer Average: " + DCAvgTime + " nano second");
		System.out.println("Kadane Average: " + KDAvgTime + " nano second");
		System.out.println();
	}
	
	@Test
	@Order(5)
	void testSize2000() 
	{
		
		BFTotalTime = 0;
		DCTotalTime = 0;
		KDTotalTime = 0;
		
		for(int i = 0; i < 10; i++)
		{
			Random random = new Random();
			int randomNumber;
			for(int j = 0; j < 2000; j++)
			{
				randomNumber=(random.nextInt(200)-100);
				arr2000[j] = randomNumber;
			}
		
			int[] bruteAnswer= new int[3];
			int[] DCAnswer = new int[3];
			int[] kadaneAnswer = new int[3];
			
			
			
			BFStartTime = System.nanoTime();
			bruteAnswer = bf.bruteForceFindMaxSubArray(arr2000);
			BFEndTime = System.nanoTime();
			BFTotalTime =+ (BFEndTime - BFStartTime);
			
			DCStartTime = System.nanoTime();
			DCAnswer = dc.findMaxSubarray(arr2000, 0, arr2000.length - 1);
			DCEndTime = System.nanoTime();
			DCTotalTime =+ (DCEndTime - DCStartTime);
			
			KDStartTime = System.nanoTime();
			kadaneAnswer = kd.kadaneFindMaxArray(arr2000);
			KDEndTime = System.nanoTime();
			KDTotalTime =+ (KDEndTime - KDStartTime);
		}
		
		BFAvgTime = BFTotalTime/10;
		DCAvgTime = DCTotalTime/10;
		KDAvgTime = KDTotalTime/10;
		
		System.out.println("Size 2000");
		System.out.println("BruteForce Average: " + BFAvgTime + " nano second");
		System.out.println("Divide&Conquer Average: " + DCAvgTime + " nano second");
		System.out.println("Kadane Average: " + KDAvgTime + " nano second");
		System.out.println();
	}
	
	@Test
	@Order(6)
	void testSize5000() 
	{
		BFTotalTime = 0;
		DCTotalTime = 0;
		KDTotalTime = 0;
		
		
		for(int i = 0; i < 10; i++)
		{
			Random random = new Random();
			int randomNumber;
			for(int j = 0; j < 5000; j++)
			{
				randomNumber=(random.nextInt(200)-100);
				arr5000[j] = randomNumber;
			}
		
			int[] bruteAnswer= new int[3];
			int[] DCAnswer = new int[3];
			int[] kadaneAnswer = new int[3];
			
			
			BFStartTime = System.nanoTime();
			bruteAnswer = bf.bruteForceFindMaxSubArray(arr5000);
			BFEndTime = System.nanoTime();
			BFTotalTime =+ (BFEndTime - BFStartTime);
			
			DCStartTime = System.nanoTime();
			DCAnswer = dc.findMaxSubarray(arr5000, 0, arr5000.length - 1);
			DCEndTime = System.nanoTime();
			DCTotalTime =+ (DCEndTime - DCStartTime);
			
			KDStartTime = System.nanoTime();
			kadaneAnswer = kd.kadaneFindMaxArray(arr5000);
			KDEndTime = System.nanoTime();
			KDTotalTime =+ (KDEndTime - KDStartTime);
		}
		
		BFAvgTime = BFTotalTime/10;
		DCAvgTime = DCTotalTime/10;
		KDAvgTime = KDTotalTime/10;
		
		System.out.println("Size 5000");
		System.out.println("BruteForce Average: " + BFAvgTime + " nano second");
		System.out.println("Divide&Conquer Average: " + DCAvgTime + " nano second");
		System.out.println("Kadane Average: " + KDAvgTime + " nano second");
		System.out.println();
	}
	
	@Test
	@Order(7)
	void testSize10000() 
	{
		
		BFTotalTime = 0;
		DCTotalTime = 0;
		KDTotalTime = 0;
		
		for(int i = 0; i < 10; i++)
		{
			Random random = new Random();
			int randomNumber;
			for(int j = 0; j < 10000; j++)
			{
				randomNumber=(random.nextInt(200)-100);
				arr10000[j] = randomNumber;
			}
		
			int[] bruteAnswer= new int[3];
			int[] DCAnswer = new int[3];
			int[] kadaneAnswer = new int[3];
			
			BFStartTime = System.nanoTime();
			bruteAnswer = bf.bruteForceFindMaxSubArray(arr10000);
			BFEndTime = System.nanoTime();
			BFTotalTime =+ (BFEndTime - BFStartTime);
			
			DCStartTime = System.nanoTime();
			DCAnswer = dc.findMaxSubarray(arr10000, 0, arr10000.length - 1);
			DCEndTime = System.nanoTime();
			DCTotalTime =+ (DCEndTime - DCStartTime);
			
			KDStartTime = System.nanoTime();
			kadaneAnswer = kd.kadaneFindMaxArray(arr10000);
			KDEndTime = System.nanoTime();
			KDTotalTime =+ (KDEndTime - KDStartTime);
		}
		
		BFAvgTime = BFTotalTime/10;
		DCAvgTime = DCTotalTime/10;
		KDAvgTime = KDTotalTime/10;
		
		System.out.println("Size 10000");
		System.out.println("BruteForce Average: " + BFAvgTime + " nano second");
		System.out.println("Divide&Conquer Average: " + DCAvgTime + " nano second");
		System.out.println("Kadane Average: " + KDAvgTime + " nano second");
		System.out.println();
	}
	
	

}


